export default function ProfileHeader({ name, bio, avatar }) {
  return (
    <>
      <img src={avatar} />
      <h4>{name}</h4>
      <p>{bio}</p>
    </>
  );
}
