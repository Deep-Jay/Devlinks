function LinkedCard({
  title,
  url,
  icon,
  visible,
  onDelete,
  onToggle,
  onMoveUp,
  onMoveDown,
  first,
  last,
}) {
  return (
    <div className="link-card">
      <span>{icon}</span>
      <p>{title}</p>
      {visible && <a href={url}>{url}</a>}
      <button onClick={onDelete}>Delete</button>
      <button onClick={onToggle}>Toggle</button>
      {!first && <button onClick={onMoveUp}>⬆️</button>}
      {!last && <button onClick={onMoveDown}>⬇️</button>}
    </div>
  );
}

export default LinkedCard;
