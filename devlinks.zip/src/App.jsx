import { useEffect, useState } from "react";
import { LinkCard, ProfileHeader } from "./components";
import UserList from "./exercises/UserList";
import UserPosts from "./exercises/UserPosts";
const demoLinks = [
  {
    id: 1,
    title: "GitHub",
    url: "https://github.com",
    icon: "🐙",
    visible: true,
  },
  {
    id: 2,
    title: "LinkedIn",
    url: "https://linkedin.com",
    icon: "💼",
    visible: true,
  },
  {
    id: 3,
    title: "Twitter",
    url: "https://twitter.com",
    icon: "🐦",
    visible: true,
  },
];
export default function App() {
  // const [links, setLinks] = useState(() => {
  //   try {
  //     const savedLinks = localStorage.getItem("links");
  //     if (savedLinks !== null) return JSON.parse(savedLinks); // key exists — trust it
  //     return demoLinks;
  //   } catch {
  //     return [];
  //   }
  // });

  // const [formState, setFormState] = useState({
  //   title: "",
  //   url: "",
  //   icon: "",
  // });

  // const handleFormStateChange = (field) => {
  //   setFormState((prev) => ({
  //     ...prev,
  //     [field.name]: field.value,
  //   }));
  // };

  // useEffect(() => {
  //   console.log("Devlinks Mounted");
  // }, []);

  // useEffect(() => {
  //   localStorage.setItem("links", JSON.stringify(links));
  //   document.title = `DevLinks (${links.length})`;
  // }, [links]);

  // const handleDelete = (id) => {
  //   setLinks((prev) => prev.filter((link) => link.id !== id));
  // };

  // const handleToggle = (id) => {
  //   setLinks((prev) =>
  //     prev.map((link) =>
  //       link.id === id ? { ...link, visible: !link.visible } : link,
  //     ),
  //   );
  // };

  // const handleSubmit = (e) => {
  //   e.preventDefault();
  //   const data = {
  //     ...formState,
  //     icon: formState.icon || "🔗",
  //     visible: true,
  //   };
  //   setLinks((prev) => [...prev, { id: Date.now(), ...data }]);
  //   setFormState({
  //     title: "",
  //     url: "",
  //     icon: "",
  //   });
  // };

  // // Move item up
  // const moveUp = (id) => {
  //   setLinks((prev) => {
  //     const index = prev.findIndex((link) => link.id === id);
  //     if (index === 0) return prev; // already first — do nothing

  //     const updated = [...prev]; // copy array
  //     [updated[index - 1], updated[index]] = [
  //       updated[index],
  //       updated[index - 1],
  //     ]; // swap
  //     return updated;
  //   });
  // };

  // // Move item down in array
  // const moveDown = (id) => {
  //   setLinks((prev) => {
  //     const index = prev.findIndex((link) => link.id === id);
  //     if (index === prev.length - 1) return prev; // already last

  //     const updated = [...prev];
  //     [updated[index + 1], updated[index]] = [
  //       updated[index],
  //       updated[index + 1],
  //     ];
  //     return updated;
  //   });
  // };
  //
  const [userId, setUserId] = useState(1);

  return (
    <div className="container">
      {/* <ProfileHeader
        name="Jaydeep"
        bio="Blanditiis ratione quibusdam iusto sit nostrum eos commodi et. Est fugiat aut sint ut aut."
        avatar="https://avatars.githubusercontent.com/u/83915597?v=4&size=64"
      />
      {links.map((link, index) => (
        <LinkCard
          key={link.id}
          url={link.url}
          icon={link.icon}
          title={link.title}
          visible={link.visible}
          onDelete={() => handleDelete(link.id)}
          onToggle={() => handleToggle(link.id)}
          onMoveUp={() => moveUp(link.id)}
          onMoveDown={() => moveDown(link.id)}
          first={index === 0}
          last={index === links.length - 1}
        />
      ))}
      <form onSubmit={handleSubmit}>
        <input
          type="text"
          name="title"
          placeholder="Title"
          value={formState.title}
          onChange={(e) => handleFormStateChange(e.target)}
          required
        />
        <input
          type="text"
          name="url"
          placeholder="Url"
          value={formState.url}
          onChange={(e) => handleFormStateChange(e.target)}
          required
        />
        <input
          type="text"
          name="icon"
          placeholder="Icon"
          value={formState.icon}
          onChange={(e) => handleFormStateChange(e.target)}
        />
        <button type="submit">Add Link</button>
      </form>*/}
      <h2>User List</h2>
      <UserList />

      <h2>User {userId} Posts</h2>
      <button onClick={() => setUserId(1)}>1</button>
      <button onClick={() => setUserId(2)}>2</button>
      <button onClick={() => setUserId(3)}>3</button>
      <UserPosts userId={userId} />
    </div>
  );
}
